<?php
session_start();
//error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
    {   
header('location:index.php');
}
else{ 

if(isset($_POST['add']))
{
$journalname=$_POST['journalname'];
$category=$_POST['category'];
$issueno=$_POST['issueno'];
$price=$_POST['price'];
$billdate=$_POST['billdate'];
$publisher=$_POST['publisher'];
foreach($issueno as $issueno){
	$sql="INSERT INTO  tbljournal(JournalName,CatId,IssueNo,Price,Date,Publisher) 
	VALUES(:journalname,:category,:issueno,:price,:billdate,:publisher)";
$query = $dbh->prepare($sql);
$query->bindParam(':journalname',$journalname,PDO::PARAM_STR);
$query->bindParam(':category',$category,PDO::PARAM_STR);
$query->bindParam(':issueno',$issueno,PDO::PARAM_STR);
$query->bindParam(':price',$price,PDO::PARAM_STR);
$query->bindParam(':billdate',$billdate,PDO::PARAM_STR);
$query->bindParam(':publisher',$publisher,PDO::PARAM_STR);
$query->execute();
}
$sql2 ="SELECT * FROM tbljournal WHERE (IssueNo=:issueno)";
$query2= $dbh -> prepare($sql2);
$query2-> bindParam(':journalid', $journalid, PDO::PARAM_STR);
$query2-> execute();
$results2 = $query2 -> fetchAll(PDO::FETCH_OBJ);
	if($query2 -> rowCount() >0)
	{
		echo "<script>alert('Record Already Exist');</script>";
	}
	else
	{
	$lastInsertId = $dbh->lastInsertId();
		if($lastInsertId)
		{
			$_SESSION['msg']="Journal Listed successfully";
			header('location:manage-journal.php');
		}
	else 
		{
			$_SESSION['error']="Something went wrong. Please try again";
			header('location:manage-journal.php');
			
	}
}
//book if over
}
?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>Online Library Management System | Add Journal</title>
    <!-- BOOTSTRAP CORE STYLE  -->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FONT AWESOME STYLE  -->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- CUSTOM STYLE  -->
    <link href="assets/css/style.css" rel="stylesheet" />
    <!-- GOOGLE FONT -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
<script>
  function validDate(){
    var today = new Date().toISOString().split('T')[0];
    document.getElementsByName("date")[0].setAttribute('min', today);
}
  </script>
</head>
<body>
      <!------MENU SECTION START-->
<?php include('includes/header.php');?>
<!-- MENU SECTION END-->
    <div class="content-wrapper">
         <div class="container">
        <div class="row pad-botm">
            <div class="col-md-12">
                <h4 class="header-line">Add Journal</h4>
                
                            </div>

</div>
<div class="row">
<div class="col-md-12 col-sm-6 col-xs-12">
<div class="panel panel-info">
<div class="panel-heading">
Journal Info
</div>
<div class="panel-body">
<form role="form" method="post">
	<div class="row">
		<div class="form-group col-md-4">
			<label>Journal Name<span style="color:red;">*</span></label>
			<input class="form-control" type="text" name="journalname" autocomplete="on"  required />
		</div>

		<div class="form-group col-md-4">
			<label> Category<span style="color:red;">*</span></label>
			<select class="form-control" name="category" required="required">
			<option value=""> Select Category</option>
			<?php 
			$status=1;
			$sql = "SELECT * from  tblcategory where Status=:status";
			$query = $dbh -> prepare($sql);
			$query -> bindParam(':status',$status, PDO::PARAM_STR);
			$query->execute();
			$results=$query->fetchAll(PDO::FETCH_OBJ);
			$cnt=1;
			if($query->rowCount() > 0)
			{
			foreach($results as $result)
			{               ?>  
			<option value="<?php echo htmlentities($result->id);?>"><?php echo htmlentities($result->CategoryName);?></option>
			 <?php }} ?> 
			</select>
		</div>
			<div class="form-group col-md-4">
			<label>Issue Number<span style="color:red;">*</span></label>
			<input class="form-control" type="text" name="issueno"  required="required" autocomplete="off" 
			placeholder="Issue Must be unique" />
			
			</div>
		

		</div>


		<div class="row">
			

			<div class="col-md-4 form-group">
			 <label>Price<span style="color:red;">*</span></label>
			 <input class="form-control" type="text" name="price" autocomplete="on"   required="required" />
			 </div>
			 
			
			 <?php 
			  $d=date("d-m-Y");
			  ?>
			<div class="form-group col-md-4">
			<label>Bill Date<span style="color:red;">*</span></label>
			<input class="form-control" type="date" name="billdate" autocomplete="on"   required="required" 
			max="<?php echo $d; ?>" />
			</div> 
			
			 <div class="form-group col-md-4">
			 <label>Publisher<span style="color:red;">*</span></label>
			 <input class="form-control" type="text" name="publisher" autocomplete="on"   required="required" />
			 </div>
			
		</div>

<button type="submit" name="add" class="btn btn-info">Add </button>

                                    </form>
                            </div>
                        </div>
                            </div>

        </div>
   
    </div>
    </div>
     <!-- CONTENT-WRAPPER SECTION END-->
  <?php include('includes/footer.php');?>
      <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT FILES PLACED AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY  -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
      <!-- CUSTOM SCRIPTS  -->
    <script src="assets/js/custom.js"></script>
</body>
</html>
<?php } ?>
