<?php
session_start();
//error_reporting(0);
//include('includes/config.php');
// Filter the excel data 
function filterData(&$str){ 
    $str = preg_replace("/\t/", "\\t", $str); 
    $str = preg_replace("/\r?\n/", "\\n", $str); 
    if(strstr($str, '"')) $str = '"' . str_replace('"', '""', $str) . '"'; 
} 

// Excel file name for download 
$fileName = "BookReport_" . date('Y-m-d') . ".xls"; 
 
// Column names 
$fields = array('ID', 'BookName', 'CategoryName', 'AuthorName', 'AccessionNumber', 'BookPrice', 'BillNo', 'BillDate' ,'Publisher'); 
 
// Display column names as first row 
$excelData = implode("\t", array_values($fields)) . "\n"; 
 
// Fetch records from database 
$query = "SELECT tblbooks.BookName,tblcategory.CategoryName,tblauthors.AuthorName,
tblbooks.ISBNNumber,tblbooks.BookPrice,tblbooks.BookStock,tblbooks.BillNo,
tblbooks.BillDate,tblbooks.Publisher,tblbooks.id as bookid from  
tblbooks join tblcategory on tblcategory.id=tblbooks.CatId 
join tblauthors on tblauthors.id=tblbooks.AuthorId"; 
//$sql ="Select * from tblbooks";
//$query = $dbh -> prepare($sql);
$con=mysqli_connect("localhost","vcbtanyb_vtcbcsr","yM$1y,]]rXqp","vcbtanyb_elibrary");
$res=mysqli_query($con,$query);
    // Output each row of the data 
    while($row = mysqli_fetch_assoc($res)){ 
        //$status = ($row['status'] == 1)?'Active':'Inactive'; 
        $lineData = array($row['bookid'], $row['BookName'], $row['CategoryName'], 
		$row['AuthorName'], $row['ISBNNumber'], $row['BookPrice'], 
		$row['BillNo'],$row['BillDate'], $row['Publisher']); 
        array_walk($lineData, 'filterData'); 
        $excelData .= implode("\t", array_values($lineData)) . "\n"; 
    } 
 
// Headers for download 
header("Content-Type: application/vnd.ms-excel"); 
header("Content-Disposition: attachment; filename=\"$fileName\""); 
 
// Render excel data 
echo $excelData; 
 
exit;
    ?>