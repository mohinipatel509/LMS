  <section class="footer-section">
        <div class="container">
            <div class="row">
               	<div class="col-md-12">
                  <center style="font-family:Bookman Old Style;font-size:120%"><B> 
				  VTCBCSR E-LIBRARY |Developed & Managed by : Ms.Mohini Patel & Ms.Rinkal Patel
				  <B> <center>
                </div>
            </div>
        </div>
    </section> 